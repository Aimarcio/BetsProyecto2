package domain;

import java.util.ArrayList;

public class ExtendedIteratorImplementation implements ExtendedIterator<Object> {

	private ArrayList<Event> list = new ArrayList<Event>();
	private int index=0;
	@Override
	public boolean hasNext() {
		if(index>=list.size()) {
			return false;
		}
		return true;
	}

	@Override
	public Object next() {
		index = index+1;
		return list.get(index-1);
	}

	@Override
	public Object previous() {
		index = index-1;
		return list.get(index+1);
	}

	@Override
	public boolean hasPrevious() {
		if(index<0) {
			return false;
		}
		return true;
	}

	@Override
	public void goFirst() {
		index=0;
		
	}

	@Override
	public void goLast() {
		index=list.size()-1;
		
	}

	
	public void add(Event o) {
		list.add(o);
	}
}
