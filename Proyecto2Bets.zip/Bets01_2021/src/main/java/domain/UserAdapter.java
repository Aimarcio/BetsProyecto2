package domain;

import javax.swing.table.TableModel;

import java.util.Vector;

import javax.swing.table.AbstractTableModel;

public class UserAdapter extends AbstractTableModel implements TableModel {

	private User user;

	public UserAdapter(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public int getRowCount() {
		int i = 0;
		Vector<Bet> apuestas = user.getApuestas();
		for (Bet p : apuestas) {
			i++;
		}
		return i;
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Vector<Bet> apuestas = user.getApuestas();
		Bet a = apuestas.get(rowIndex);
		switch (columnIndex) {
		case 0:
			return a.getEventoAsociado();
		case 1:
			return a.getPreguntaAsociada();
		case 2:
			return a.getEventoAsociado().getEventDate();
		case 3:
			return a.getCantidad();
		default:
			return null;
		}
	}

	@Override
	public String getColumnName(int col) {
		switch (col) {
		case 0:
			return "Event";
		case 1:
			return "Question";
		case 2:
			return "Event Date";
		case 3:
			return "Bet (�)";
		default:
			return "Error";
		}
	}

}
